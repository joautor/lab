-- @Delete one row
-- @Delete multiple rows (WHERE condition matches multiple rows)
-- @Using LIKE operator in WHERE clause
-- @Using operators other than = and LIKE in WHERE clause

-- 1 delete an enrollment (goodbye)
DELETE attendance, enrollments
FROM enrollments
LEFT JOIN attendance
ON enrollments.id = attendance.enrollment_id
WHERE enrollment.id = 1;


-- 2 bye student
DELETE attendance, scores, enrollments, students
FROM students
LEFT JOIN enrollments
ON students.id = enrollments.student_id
LEFT JOIN scores
ON students.id = scores.student_id
LEFT JOIN attendance
ON enrollments.id = attendance.enrollment_id
WHERE students.lastname = 'Juan';


-- 5 nag sit-in si student
DELETE attendance
FROM attendance
WHERE attendance.date LIKE '2017-10-03' AND enrollment_id = 4;
-- 6 delete a subject

DELETE sections, scores, schedules, requirements, enrollments, documents, attendance, attachments, activities, subjects
FROM subjects
	LEFT JOIN activities
	ON subjects.id = activities.subject_id
    LEFT JOIN documents
	ON subjects.id = documents.subject_id
    LEFT JOIN sections
	ON subjects.id = sections.subject_id 
    LEFT JOIN requirements
	ON subjects.id = requirements.subject_id
    	LEFT JOIN attachments
        ON activities.id = attachments.activity_id
    
