USE courseware;


INSERT INTO subjects VALUES
(0,"CMSC 141","141","FS1718"),
(0,"CMSC 127","127","FS1718"),
(0,"CMSC 198.1","198","FS1718"),
(0,"CMSC 123","123","SS1718"),
(0,"CMSC 170","170","SS1718");


INSERT INTO students VALUES
(0,"201500001","Tan","Peter","201500001"),
(0,"201500002","Mercado","Girlie","201500002"),
(0,"201500003","Dela Cruz","Juan","201500003"),
(0,"201500004","Dela Rosa","Rose","201500004"),
(0,"201400001","Garcia","Carlos","201400001"),
(0,"201400002","Gomez","Richie","201400002"),
(0,"201400003","Ong" ,"Bob","201400003"),
(0,"201400004","Perez","CJ","201400004"),
(0,"201600001","Lopez","Robin","201600001"),
(0,"201600002","Lustre","James","201600002"),
(0,"201600003","Padilla","Kathy","201600003");



INSERT INTO sections VALUES
(0,1,"1","lec","10:00-11:30","M-Th"),
(0,1,"2","lec","1:00-2:30","T-F"),
(0,2,"1","lab","2:30-4:00","M-Th"),
(0,2,"2","lab","4:00-5:30","M-Th"),
(0,2,"3","lab","10:00-11:30","T-F"),
(0,3,"3","lec","9:00-10:00","M-Th"),
(0,4,"1","lec","10:00-11:30","M-Th"),
(0,5,"1","lec","10:00-11:30","T-F");



INSERT INTO enrollments VALUES
(0,1,1,"active"),
(0,2,1,"active"),
(0,3,2,"active"),
(0,4,2,"active"),
(0,1,3,"active"),
(0,2,4,"active"),
(0,3,4,"active"),
(0,4,5,"active"),
(0,5,6,"active"),
(0,6,6,"active"),
(0,7,6,"active"),
(0,9,7,"active"),
(0,10,7,"active"),
(0,11,7,"active"),
(0,6,8,"active"),
(0,7,8,"active"),
(0,8,8,"active");



INSERT INTO attendance VALUES
(1,2,"2017-10-02","absent"),
(2,4,"2017-10-03","absent"),
(3,3,"2017-10-03","late"),
(4,2,"2017-10-09","late"),
(5,9,"2017-10-02","absent");




INSERT INTO requirements VALUES
(1,1,"lec","Long Exams",60),
(2,1,"lec","Assignments/Quizzes",25),
(3,1,"lec","Final Project",15),
(4,2,"lab","Lab Activities",75),
(5,2,"lab","Final Project",25),
(6,3,"lec","Proposal",50),
(7,3,"lec","Prototype",50);



INSERT INTO activities VALUES
(1,1,"lec","Lecture 1",TRUE,FALSE,NULL,NULL),
(2,1,"lec","No Class",TRUE,FALSE,NULL,NULL),
(3,1,"lec","Quiz 1",TRUE,FALSE,15,2),
(4,1,"lec","Exam 1",TRUE,FALSE,100,1),
(5,2,"lab","Activity 1",TRUE,TRUE,25,4),
(6,2,"lab","Activity 2",TRUE,TRUE,25,4),
(7,2,"lab","Activity 3",FALSE,TRUE,40,4),
(8,3,"lec","Lecture 1",TRUE,FALSE,NULL,NULL),
(9,3,"lec","No Class",TRUE,FALSE,NULL,NULL);



INSERT INTO scores VALUES
(1,3,1,10),
(2,3,2,0),
(3,3,3,13),
(4,3,4,14),
(5,4,1,77),
(6,4,2,82),
(7,4,3,95),
(8,4,4,68),
(9,5,1,20),
(10,5,2,22),
(11,5,3,24),
(12,5,4,25);




INSERT INTO schedules VALUES
(1,1,1,"2017-08-07"),
(2,2,1,"2017-08-21"),
(3,2,1,"2017-08-28"),
(4,3,1,"2017-08-07"),
(5,4,1,"2017-09-20"),
(6,5,1,"2017-08-14"),
(7,5,1,"2017-08-17"),
(8,6,1,"2017-08-24"),
(9,6,1,"2017-08-31"),
(10,7,1,"2017-09-04"),
(11,7,1,"2017-09-07"),
(12,1,2,"2017-08-08"),
(13,2,2,"2017-08-25"),
(14,2,2,"2017-09-01"),
(15,3,2,"2017-08-08"),
(16,4,2,"2017-09-20"),
(17,5,2,"2017-08-14"),
(18,5,2,"2017-08-17"),
(19,6,2,"2017-08-24"),
(20,6,2,"2017-08-31"),
(21,7,2,"2017-09-04"),
(22,7,2,"2017-09-07"),
(23,5,3,"2017-08-15"),
(24,5,3,"2017-08-18"),
(25,6,3,"2017-08-22"),
(26,6,3,"2017-08-29"),
(27,7,3,"2017-09-05"),
(28,7,3,"2017-09-08");



INSERT INTO documents VALUES
(1,1,"lec","Intro to CMSC 141","141_lec1.pdf","pdf",TRUE),
(2,2,"lab","Activity 1","lab1.zip","compressed",TRUE),
(3,2,"lab","Activity 1 Solution","lab1_solution.pdf","pdf",FALSE),
(4,2,"lab","Activity 2","lab2.zip","compressed",TRUE),
(5,2,"lab","Activity 2 Solution","lab2_solution.pdf","pdf",FALSE),
(6,2,"lab","Activity 3","lab3.zip","compressed",TRUE),
(7,2,"lab","Activity 3 Solution","lab3_solution.pdf","pdf",FALSE),
(8,3,"lec","Intro to CMSC 198","198_lec1.pdf","pdf",TRUE);



INSERT INTO attachments VALUES
(1,1,1),
(2,5,2),
(3,5,3),
(4,6,4),
(5,6,5),
(6,7,6),
(7,7,7),
(8,8,8);

