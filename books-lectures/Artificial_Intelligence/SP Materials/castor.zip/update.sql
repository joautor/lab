USE courseware;

-- 1 change final project to final exam in lec
UPDATE requirements
SET name = "Final Exam"
WHERE subject_type LIKE "lec" AND name LIKE "Final Project";


-- 2 4:00-5:30 is on T-F
UPDATE sections 
SET days = "T-F"
WHERE timeslot LIKE "4:00%";

-- 3 labs that starts on 10:00 will be moved to wednesday and wil be extended
UPDATE sections
SET days = "W", timeslot = "10:00-1:00"
WHERE timeslot LIKE "10:00%" AND subject_type LIKE "lab";

-- 4 change the no class into an assignment
UPDATE activities
SET name = "Assignment 1", total_score = 50, requirement_id = 2
WHERE subject_id = 1 AND name LIKE "No Class";

-- 5 students cheated in an activity so they are all 0 (quiz 1)
UPDATE scores
SET activity_id = 3, score = 0
WHERE activity_id = 3;

-- 6 all activities are made public
UPDATE activities
SET is_public = 1
WHERE is_public != 1;

-- 7 a student changes his/her password
UPDATE students
SET password  = "Asd59456"
WHERE id = 1;

-- 8 student legally changed name
UPDATE students
SET firstname = "Maggie", lastname = "Nudels" 
WHERE id = 10;

-- 9   10 -1130 subject id 2 cmsc 127 is lec
UPDATE sections
SET timeslot = "4:00-5:00", subject_type = "lec", number = 1
WHERE subject_id = 2 AND timeslot LIKE "4:00-5:30";

-- 10 a student defended his/her answer so add points
UPDATE scores
SET score = 85
WHERE activity_id = 4 AND student_id = 2;

-- 11 drop a student
UPDATE enrollments
SET status = "dropped"
WHERE student_id = 2 AND section_id = 1;
